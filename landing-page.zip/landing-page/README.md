# Landing Page Project
The starter project has some HTML and CSS styling to display a static version of the Landing Page project.

# what i have done in this project
There are 5 sections that have been added to the page.
and All features are usable across modern desktop, tablet, and phone browsers.
it is clear which section is being viewed while scrolling through the page.

# the langauge i used
1-HTML
2-CSS
3-Javascript

i used javascript to dynamically create navbar links based on the content, when a section is in the viewport it shows the active state of that section.

# Notes

i removed Document.createDocumentFragment() and the top button because i got them online but i really understand how to use them so i put them but maybe they were the main reason.